#!/bin/bash
# ─────────────────────────────────────────────
#  AI for Release Train Engineers
#  Setup & Run Script (Mac / Linux)
# ─────────────────────────────────────────────

# Go to the folder where this script lives
cd "$(dirname "$0")"

echo ""
echo "=========================================="
echo "  AI for Release Train Engineers"
echo "  Setting up..."
echo "=========================================="
echo ""

# Check if Python 3 is installed
if command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
elif command -v python &> /dev/null; then
    # Check if it's Python 3
    PY_VERSION=$(python --version 2>&1 | grep -o '3\.')
    if [ -n "$PY_VERSION" ]; then
        PYTHON_CMD="python"
    else
        echo "  Python 3 is not installed."
        echo ""
        echo "  Please install Python 3:"
        echo "    Mac: Download from https://www.python.org/downloads/"
        echo "    Linux: sudo apt install python3 python3-pip"
        echo ""
        read -p "  Press Enter to exit..."
        exit 1
    fi
else
    echo "  Python is not installed."
    echo ""
    echo "  Please install Python 3:"
    echo "    Mac: Download from https://www.python.org/downloads/"
    echo "    Linux: sudo apt install python3 python3-pip"
    echo ""
    read -p "  Press Enter to exit..."
    exit 1
fi

echo "  Found: $($PYTHON_CMD --version)"

# Install dependencies (only on first run)
if [ ! -f "config/.setup_done" ]; then
    echo ""
    echo "  Installing required packages (one-time setup)..."
    echo ""
    $PYTHON_CMD -m pip install -r requirements.txt --quiet
    if [ $? -ne 0 ]; then
        echo ""
        echo "  Could not install packages. Trying with --user flag..."
        $PYTHON_CMD -m pip install -r requirements.txt --user --quiet
    fi
    mkdir -p config
    touch config/.setup_done
    echo ""
    echo "  Setup complete!"
fi

echo ""

# Run the file watcher
$PYTHON_CMD scripts/file_watcher.py

echo ""
read -p "  Press Enter to exit..."
