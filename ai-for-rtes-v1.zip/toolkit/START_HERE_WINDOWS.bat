@echo off
REM ─────────────────────────────────────────────
REM  AI for Release Train Engineers
REM  Setup & Run Script (Windows)
REM ─────────────────────────────────────────────

cd /d "%~dp0"

echo.
echo ==========================================
echo   AI for Release Train Engineers
echo   Setting up...
echo ==========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    python3 --version >nul 2>&1
    if %errorlevel% neq 0 (
        echo   Python is not installed.
        echo.
        echo   Please install Python 3:
        echo     1. Go to https://www.python.org/downloads/
        echo     2. Download Python 3
        echo     3. IMPORTANT: Check "Add Python to PATH" during install
        echo     4. Run this file again
        echo.
        pause
        exit /b 1
    ) else (
        set PYTHON_CMD=python3
    )
) else (
    set PYTHON_CMD=python
)

echo   Found Python.

REM Install dependencies (only on first run)
if not exist "config\.setup_done" (
    echo.
    echo   Installing required packages (one-time setup)...
    echo.
    %PYTHON_CMD% -m pip install -r requirements.txt --quiet
    if %errorlevel% neq 0 (
        echo.
        echo   Trying with --user flag...
        %PYTHON_CMD% -m pip install -r requirements.txt --user --quiet
    )
    if not exist "config" mkdir config
    echo. > config\.setup_done
    echo.
    echo   Setup complete!
)

echo.

REM Run the file watcher
%PYTHON_CMD% scripts\file_watcher.py

echo.
pause
