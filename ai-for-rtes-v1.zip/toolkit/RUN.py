#!/usr/bin/env python3
"""
AI for Release Train Engineers
Double-click this file to start.
"""

import subprocess
import sys
import os

# Go to the toolkit folder (where this file lives)
os.chdir(os.path.dirname(os.path.abspath(__file__)))

# Install dependencies if first run
if not os.path.exists("config/.setup_done"):
    print()
    print("==========================================")
    print("  AI for Release Train Engineers")
    print("  First-time setup...")
    print("==========================================")
    print()
    print("  Installing required packages...")
    print()
    subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt", "--quiet"])
    os.makedirs("config", exist_ok=True)
    with open("config/.setup_done", "w") as f:
        f.write("done")
    print()
    print("  Setup complete!")

# Run the file watcher
subprocess.call([sys.executable, "scripts/file_watcher.py"])
