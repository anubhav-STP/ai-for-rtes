#!/usr/bin/env python3
"""
AI for RTEs - File Watcher
Monitors input/ folder for new CSV/Excel files and triggers the reporting pipeline.

Drop your ALM export file into the input/ folder.
Reports appear in the output/ folder and open in your browser.
"""

import os
import sys
import time
import json
import subprocess
import webbrowser
import threading
from pathlib import Path

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
except ImportError:
    print()
    print("  Missing required package: watchdog")
    print("  Please run: pip install watchdog")
    print()
    sys.exit(1)

# Configuration
INPUT_DIR = "input"
OUTPUT_DIR = "output"
PROCESSED_TRACKER = "config/.processed_files.json"
DASHBOARD_PATH = os.path.join(OUTPUT_DIR, "rte_dashboard.html")
QUIET_PERIOD_SECONDS = 3

SUPPORTED_EXTENSIONS = ('.csv', '.xlsx', '.xls')


class FileHandler(FileSystemEventHandler):
    """Handles new file events in the input directory."""

    def __init__(self):
        self.processed_files = self._load_processed()
        self.processing = False
        self.should_exit = False
        self.files_processed_count = 0
        self.quiet_timer = None

    def _load_processed(self):
        if os.path.exists(PROCESSED_TRACKER):
            try:
                with open(PROCESSED_TRACKER, 'r') as f:
                    return set(json.load(f))
            except Exception:
                return set()
        return set()

    def _save_processed(self, filename):
        self.processed_files.add(filename)
        os.makedirs(os.path.dirname(PROCESSED_TRACKER), exist_ok=True)
        with open(PROCESSED_TRACKER, 'w') as f:
            json.dump(list(self.processed_files), f)

    def process_existing_files(self):
        """Process all unprocessed files at startup."""
        print()
        print("=" * 60)
        print("  Scanning for new files...")
        print("=" * 60)

        files_to_process = []

        for filename in sorted(os.listdir(INPUT_DIR)):
            if not filename.lower().endswith(SUPPORTED_EXTENSIONS):
                continue
            if filename.startswith('~$') or filename.startswith('.'):
                continue
            if filename in self.processed_files:
                print(f"  Skipping {filename} (already processed)")
                continue
            files_to_process.append(filename)

        if not files_to_process:
            print("  No new files found.")
            return

        print(f"  Found {len(files_to_process)} file(s) to process:")
        for f in files_to_process:
            print(f"    - {f}")

        for i, filename in enumerate(files_to_process, 1):
            filepath = os.path.join(INPUT_DIR, filename)
            print()
            print(f"  Processing [{i}/{len(files_to_process)}]: {filename}")
            self._run_pipeline(filepath, filename)
            self._save_processed(filename)
            self.files_processed_count += 1

        if files_to_process:
            print()
            print("=" * 60)
            print(f"  Done! Processed {len(files_to_process)} file(s).")
            print("=" * 60)
            self._open_dashboard()
            self.should_exit = True

    def on_created(self, event):
        if event.is_directory:
            return

        filepath = event.src_path
        filename = os.path.basename(filepath)

        if not filename.lower().endswith(SUPPORTED_EXTENSIONS):
            return
        if filename.startswith('~$') or filename.startswith('.'):
            return
        if filename in self.processed_files:
            return
        if self.processing:
            return

        print()
        print(f"  New file: {filename}")

        # Wait for file to finish writing
        time.sleep(2)

        self._run_pipeline(filepath, filename)
        self._save_processed(filename)
        self.files_processed_count += 1

        # Debounce — wait for more files before opening dashboard
        if self.quiet_timer:
            self.quiet_timer.cancel()
        self.quiet_timer = threading.Timer(QUIET_PERIOD_SECONDS, self._finalize)
        self.quiet_timer.start()

    def _finalize(self):
        print()
        print(f"  All files processed ({self.files_processed_count} total).")
        self._open_dashboard()
        self.should_exit = True

    def _run_pipeline(self, filepath, filename):
        """Run the full processing pipeline."""
        self.processing = True
        try:
            # Determine python command
            python_cmd = sys.executable

            # Step 1: Parse and calculate reports
            print(f"  [1/2] Reading and analyzing data...")
            result = subprocess.run(
                [python_cmd, 'scripts/parse_and_calculate.py', filepath],
                capture_output=True, text=True
            )
            if result.returncode != 0:
                print(f"  Error reading data:")
                print(f"  {result.stderr[:500]}")
                if result.stdout:
                    print(f"  {result.stdout[:500]}")
                return
            if result.stdout:
                # Print key lines from output
                for line in result.stdout.strip().split('\n'):
                    if line.strip():
                        print(f"    {line.strip()}")

            # Step 2: Generate dashboard
            print(f"  [2/2] Generating reports...")
            result = subprocess.run(
                [python_cmd, 'scripts/generate_dashboard.py'],
                capture_output=True, text=True
            )
            if result.returncode != 0:
                print(f"  Error generating reports:")
                print(f"  {result.stderr[:500]}")
                return
            if result.stdout:
                for line in result.stdout.strip().split('\n'):
                    if line.strip():
                        print(f"    {line.strip()}")

            print(f"  Done: {filename}")

        except Exception as e:
            print(f"  Error: {e}")
        finally:
            self.processing = False

    def _open_dashboard(self):
        dashboard_path = os.path.abspath(DASHBOARD_PATH)
        if not os.path.exists(dashboard_path):
            print(f"  Report not found at: {DASHBOARD_PATH}")
            return

        print()
        print(f"  Opening report in your browser...")
        try:
            file_url = Path(dashboard_path).as_uri()
            webbrowser.open(file_url)
            print(f"  Report opened!")
        except Exception as e:
            print(f"  Could not open browser automatically.")
            print(f"  Please open this file: {dashboard_path}")


def main():
    print()
    print("=" * 60)
    print("  AI FOR RELEASE TRAIN ENGINEERS")
    print("  Metrics & Reporting Tool")
    print("=" * 60)
    print()
    print("  How to use:")
    print("    1. Export your data from your ALM tool (Jira, Rally, etc.)")
    print("       as CSV or Excel (.xlsx)")
    print("    2. Drop the file into the 'input' folder")
    print("    3. Your reports will open in the browser")
    print()
    print(f"  Watching: {os.path.abspath(INPUT_DIR)}")
    print(f"  Reports:  {os.path.abspath(OUTPUT_DIR)}")
    print()

    # Create folders
    for folder in [INPUT_DIR, OUTPUT_DIR, 'config', 'temp', 'historical']:
        os.makedirs(folder, exist_ok=True)

    handler = FileHandler()
    handler.process_existing_files()

    if handler.should_exit:
        return

    print()
    print("  Waiting for files... (drop a file into the input folder)")
    print("  Press Ctrl+C to stop.")
    print()

    observer = Observer()
    observer.schedule(handler, INPUT_DIR, recursive=False)
    observer.start()

    try:
        while not handler.should_exit:
            time.sleep(1)
    except KeyboardInterrupt:
        print()
        print("  Stopping...")
        if handler.quiet_timer:
            handler.quiet_timer.cancel()

    observer.stop()
    observer.join()
    print("  Goodbye!")


if __name__ == "__main__":
    if sys.version_info[0] < 3:
        print("  This tool requires Python 3. Please install Python 3 from python.org")
        sys.exit(1)
    main()
