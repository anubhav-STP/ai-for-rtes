#!/usr/bin/env python3
"""
AI for RTEs - Data Parser & Report Calculator
Reads CSV/Excel files, applies column mapping, and calculates all metrics.

This is the core engine. It:
1. Reads the file
2. Maps columns (auto-detect or use saved mapping)
3. Calculates all possible reports based on available data
4. Saves results to temp/ and historical/
"""

import sys
import json
import os
import re
import numpy as np
import pandas as pd
from datetime import datetime
from pathlib import Path

# Add scripts dir to path for imports
sys.path.insert(0, os.path.dirname(__file__))
from column_mapper import get_column_mapping, DONE_STATUS_KEYWORDS


def read_file(filepath):
    """Read CSV or Excel file into a pandas DataFrame."""
    ext = Path(filepath).suffix.lower()
    try:
        if ext == '.csv':
            # Try common encodings
            for encoding in ['utf-8', 'latin-1', 'cp1252']:
                try:
                    df = pd.read_csv(filepath, encoding=encoding)
                    break
                except UnicodeDecodeError:
                    continue
            else:
                df = pd.read_csv(filepath, encoding='utf-8', errors='replace')
        elif ext in ('.xlsx', '.xls'):
            df = pd.read_excel(filepath)
        else:
            print(f"  Unsupported file type: {ext}")
            sys.exit(1)

        print(f"  Read {len(df)} rows, {len(df.columns)} columns")
        return df
    except Exception as e:
        print(f"  Could not read file: {e}")
        sys.exit(1)


def is_done(status_value):
    """Check if a status value indicates 'done'."""
    if pd.isna(status_value):
        return False
    status_lower = str(status_value).lower().strip()
    return any(kw in status_lower for kw in DONE_STATUS_KEYWORDS)


def calculate_velocity(df, mapping):
    """
    Velocity: Story points completed per team per sprint.
    Requires: team, sprint, story_points, status
    """
    if not all(k in mapping for k in ['team', 'sprint', 'story_points', 'status']):
        return None

    team_col = mapping['team']
    sprint_col = mapping['sprint']
    points_col = mapping['story_points']
    status_col = mapping['status']

    # Filter to done items with points
    done_mask = df[status_col].apply(is_done)
    has_points = pd.to_numeric(df[points_col], errors='coerce').notna()
    has_team = df[team_col].notna()
    has_sprint = df[sprint_col].notna()

    work = df[done_mask & has_points & has_team & has_sprint].copy()
    work[points_col] = pd.to_numeric(work[points_col], errors='coerce')

    if work.empty:
        return {"teams": {}, "sprints": [], "summary": "No completed items found"}

    # Group by team and sprint
    velocity = work.groupby([team_col, sprint_col])[points_col].sum().reset_index()
    velocity.columns = ['team', 'sprint', 'points']

    # Build result
    sprints = sorted(velocity['sprint'].unique().tolist(), key=str)
    teams = {}

    for team in velocity['team'].unique():
        team_data = velocity[velocity['team'] == team]
        sprint_points = {}
        for _, row in team_data.iterrows():
            sprint_points[str(row['sprint'])] = float(row['points'])

        points_list = list(sprint_points.values())
        teams[str(team)] = {
            'sprints': sprint_points,
            'total': sum(points_list),
            'average': round(sum(points_list) / len(points_list), 1) if points_list else 0
        }

    return {
        'teams': teams,
        'sprints': [str(s) for s in sprints],
        'total_velocity': sum(t['total'] for t in teams.values()),
        'team_count': len(teams)
    }


def calculate_scope_change(df, mapping):
    """
    Scope Change: Items added/removed per sprint.
    Compares committed (at sprint start) vs actual (end of sprint).
    Uses created_date if available, otherwise counts by status.
    Requires: team, sprint, story_points, status
    """
    if not all(k in mapping for k in ['team', 'sprint', 'story_points', 'status']):
        return None

    team_col = mapping['team']
    sprint_col = mapping['sprint']
    points_col = mapping['story_points']
    status_col = mapping['status']

    has_team = df[team_col].notna()
    has_sprint = df[sprint_col].notna()
    work = df[has_team & has_sprint].copy()
    work[points_col] = pd.to_numeric(work[points_col], errors='coerce').fillna(0)

    if work.empty:
        return None

    # Total items and points per sprint per team
    sprint_scope = work.groupby([team_col, sprint_col]).agg(
        item_count=(points_col, 'count'),
        total_points=(points_col, 'sum')
    ).reset_index()
    sprint_scope.columns = ['team', 'sprint', 'item_count', 'total_points']

    # Done items per sprint per team
    done_mask = work[status_col].apply(is_done)
    done_work = work[done_mask]
    done_scope = done_work.groupby([team_col, sprint_col]).agg(
        done_count=(points_col, 'count'),
        done_points=(points_col, 'sum')
    ).reset_index()
    done_scope.columns = ['team', 'sprint', 'done_count', 'done_points']

    merged = sprint_scope.merge(done_scope, on=['team', 'sprint'], how='left').fillna(0)

    result = {}
    for _, row in merged.iterrows():
        team = str(row['team'])
        sprint = str(row['sprint'])
        if team not in result:
            result[team] = {}
        result[team][sprint] = {
            'total_items': int(row['item_count']),
            'total_points': float(row['total_points']),
            'done_items': int(row['done_count']),
            'done_points': float(row['done_points']),
            'completion_rate': round(row['done_points'] / row['total_points'] * 100, 1) if row['total_points'] > 0 else 0
        }

    return result


def calculate_work_distribution(df, mapping):
    """
    Work item distribution by type and status.
    """
    status_col = mapping.get('status')
    type_col = mapping.get('issue_type')
    points_col = mapping.get('story_points')

    if not status_col:
        return None

    result = {}

    # By status
    status_counts = df[status_col].value_counts().to_dict()
    result['by_status'] = {str(k): int(v) for k, v in status_counts.items() if pd.notna(k)}

    # By type (if available)
    if type_col and type_col in df.columns:
        type_counts = df[type_col].value_counts().to_dict()
        result['by_type'] = {str(k): int(v) for k, v in type_counts.items() if pd.notna(k)}

        # Type x Status matrix
        if status_col in df.columns:
            cross = pd.crosstab(df[type_col].fillna('Unknown'), df[status_col].fillna('Unknown'))
            result['type_status_matrix'] = {
                str(t): {str(s): int(v) for s, v in row.items()}
                for t, row in cross.iterrows()
            }

    # Points distribution if available
    if points_col and points_col in df.columns:
        df_copy = df.copy()
        df_copy[points_col] = pd.to_numeric(df_copy[points_col], errors='coerce')
        points_by_status = df_copy.groupby(status_col)[points_col].sum()
        result['points_by_status'] = {str(k): float(v) for k, v in points_by_status.items() if pd.notna(k) and v > 0}

    return result


def calculate_cycle_time(df, mapping):
    """
    Cycle time: days from created to resolved.
    Requires: created_date, resolved_date
    """
    created_col = mapping.get('created_date')
    resolved_col = mapping.get('resolved_date')

    if not created_col or not resolved_col:
        return None

    df_copy = df.copy()

    # Parse dates
    df_copy['_created'] = pd.to_datetime(df_copy[created_col], errors='coerce')
    df_copy['_resolved'] = pd.to_datetime(df_copy[resolved_col], errors='coerce')

    # Filter to items that have both dates
    valid = df_copy[df_copy['_created'].notna() & df_copy['_resolved'].notna()].copy()

    if valid.empty:
        return None

    valid['_cycle_days'] = (valid['_resolved'] - valid['_created']).dt.days

    # Remove negative cycle times
    valid = valid[valid['_cycle_days'] >= 0]

    if valid.empty:
        return None

    result = {
        'overall': {
            'average_days': round(valid['_cycle_days'].mean(), 1),
            'median_days': round(valid['_cycle_days'].median(), 1),
            'min_days': int(valid['_cycle_days'].min()),
            'max_days': int(valid['_cycle_days'].max()),
            'items_measured': len(valid)
        }
    }

    # By team if available
    team_col = mapping.get('team')
    if team_col and team_col in valid.columns:
        team_cycle = valid.groupby(team_col)['_cycle_days'].agg(['mean', 'median', 'count'])
        result['by_team'] = {
            str(team): {
                'average_days': round(row['mean'], 1),
                'median_days': round(row['median'], 1),
                'items_measured': int(row['count'])
            }
            for team, row in team_cycle.iterrows() if pd.notna(team)
        }

    # By type if available
    type_col = mapping.get('issue_type')
    if type_col and type_col in valid.columns:
        type_cycle = valid.groupby(type_col)['_cycle_days'].agg(['mean', 'median', 'count'])
        result['by_type'] = {
            str(t): {
                'average_days': round(row['mean'], 1),
                'median_days': round(row['median'], 1),
                'items_measured': int(row['count'])
            }
            for t, row in type_cycle.iterrows() if pd.notna(t)
        }

    # Distribution buckets
    buckets = {'0-3 days': 0, '4-7 days': 0, '1-2 weeks': 0, '2-4 weeks': 0, '1+ month': 0}
    for days in valid['_cycle_days']:
        if days <= 3:
            buckets['0-3 days'] += 1
        elif days <= 7:
            buckets['4-7 days'] += 1
        elif days <= 14:
            buckets['1-2 weeks'] += 1
        elif days <= 28:
            buckets['2-4 weeks'] += 1
        else:
            buckets['1+ month'] += 1
    result['distribution'] = buckets

    return result


def calculate_epic_progress(df, mapping):
    """
    Epic/Feature progress tracking.
    Requires: epic, status (optionally story_points)
    """
    epic_col = mapping.get('epic')
    status_col = mapping.get('status')

    if not epic_col or not status_col:
        return None

    has_epic = df[epic_col].notna()
    work = df[has_epic].copy()

    if work.empty:
        return None

    points_col = mapping.get('story_points')
    has_points = points_col and points_col in work.columns

    if has_points:
        work['_points'] = pd.to_numeric(work[points_col], errors='coerce').fillna(0)

    result = {}
    for epic_name, group in work.groupby(epic_col):
        epic_data = {
            'total_items': len(group),
            'done_items': int(group[status_col].apply(is_done).sum()),
        }
        epic_data['completion_pct'] = round(epic_data['done_items'] / epic_data['total_items'] * 100, 1) if epic_data['total_items'] > 0 else 0

        if has_points:
            total_pts = group['_points'].sum()
            done_pts = group[group[status_col].apply(is_done)]['_points'].sum()
            epic_data['total_points'] = float(total_pts)
            epic_data['done_points'] = float(done_pts)
            epic_data['points_completion_pct'] = round(done_pts / total_pts * 100, 1) if total_pts > 0 else 0

        # Status breakdown
        status_counts = group[status_col].value_counts().to_dict()
        epic_data['status_breakdown'] = {str(k): int(v) for k, v in status_counts.items()}

        result[str(epic_name)] = epic_data

    return result


def calculate_priority_breakdown(df, mapping):
    """
    Priority breakdown with status distribution.
    """
    priority_col = mapping.get('priority')
    status_col = mapping.get('status')

    if not priority_col or not status_col:
        return None

    valid = df[df[priority_col].notna()].copy()
    if valid.empty:
        return None

    result = {}
    for priority, group in valid.groupby(priority_col):
        total = len(group)
        done = int(group[status_col].apply(is_done).sum())
        result[str(priority)] = {
            'total': total,
            'done': done,
            'completion_pct': round(done / total * 100, 1) if total > 0 else 0,
            'status_breakdown': {str(k): int(v) for k, v in group[status_col].value_counts().to_dict().items()}
        }

    return result


def calculate_team_comparison(df, mapping):
    """
    Team comparison: side-by-side metrics for all teams.
    Requires: team, story_points, status
    """
    team_col = mapping.get('team')
    points_col = mapping.get('story_points')
    status_col = mapping.get('status')

    if not all([team_col, points_col, status_col]):
        return None

    work = df[df[team_col].notna()].copy()
    work['_points'] = pd.to_numeric(work[points_col], errors='coerce').fillna(0)

    if work.empty:
        return None

    result = {}
    for team, group in work.groupby(team_col):
        total_items = len(group)
        done_items = int(group[status_col].apply(is_done).sum())
        total_points = float(group['_points'].sum())
        done_points = float(group[group[status_col].apply(is_done)]['_points'].sum())

        team_data = {
            'total_items': total_items,
            'done_items': done_items,
            'total_points': total_points,
            'done_points': done_points,
            'completion_pct': round(done_items / total_items * 100, 1) if total_items > 0 else 0,
            'points_completion_pct': round(done_points / total_points * 100, 1) if total_points > 0 else 0
        }

        # Average points per item
        if total_items > 0:
            team_data['avg_points_per_item'] = round(total_points / total_items, 1)

        result[str(team)] = team_data

    return result


def main():
    if len(sys.argv) < 2:
        print("  Usage: python parse_and_calculate.py <filepath>")
        sys.exit(1)

    filepath = sys.argv[1]
    if not Path(filepath).exists():
        print(f"  File not found: {filepath}")
        sys.exit(1)

    # Step 1: Read the file
    print(f"  Reading: {Path(filepath).name}")
    df = read_file(filepath)

    # Step 2: Get column mapping
    column_headers = df.columns.tolist()
    mapping = get_column_mapping(column_headers)

    if not mapping:
        print("  No columns could be mapped. Please check your file format.")
        sys.exit(1)

    # Step 3: Calculate all possible reports
    print("  Calculating reports...")

    reports = {
        'metadata': {
            'source_file': Path(filepath).name,
            'generated_at': datetime.now().isoformat(),
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'column_mapping': mapping
        },
        'available_reports': []
    }

    # Velocity
    velocity = calculate_velocity(df, mapping)
    if velocity:
        reports['velocity'] = velocity
        reports['available_reports'].append('velocity')
        print(f"    Velocity: {velocity.get('team_count', 0)} teams across {len(velocity.get('sprints', []))} sprints")

    # Scope Change
    scope = calculate_scope_change(df, mapping)
    if scope:
        reports['scope_change'] = scope
        reports['available_reports'].append('scope_change')
        print(f"    Scope Change: {len(scope)} teams tracked")

    # Work Distribution
    distribution = calculate_work_distribution(df, mapping)
    if distribution:
        reports['work_distribution'] = distribution
        reports['available_reports'].append('work_distribution')
        print(f"    Work Distribution: {len(distribution.get('by_status', {}))} statuses")

    # Cycle Time
    cycle = calculate_cycle_time(df, mapping)
    if cycle:
        reports['cycle_time'] = cycle
        reports['available_reports'].append('cycle_time')
        print(f"    Cycle Time: avg {cycle['overall']['average_days']} days ({cycle['overall']['items_measured']} items)")

    # Epic Progress
    epics = calculate_epic_progress(df, mapping)
    if epics:
        reports['epic_progress'] = epics
        reports['available_reports'].append('epic_progress')
        print(f"    Epic Progress: {len(epics)} epics tracked")

    # Priority Breakdown
    priority = calculate_priority_breakdown(df, mapping)
    if priority:
        reports['priority_breakdown'] = priority
        reports['available_reports'].append('priority_breakdown')
        print(f"    Priority Breakdown: {len(priority)} priority levels")

    # Team Comparison
    team_comp = calculate_team_comparison(df, mapping)
    if team_comp:
        reports['team_comparison'] = team_comp
        reports['available_reports'].append('team_comparison')
        print(f"    Team Comparison: {len(team_comp)} teams")

    if not reports['available_reports']:
        print("  Could not generate any reports from this data.")
        print("  Please check that your columns are mapped correctly.")
        print("  Delete config/column_mapping.json to re-map columns.")
        sys.exit(1)

    # Step 4: Save results
    os.makedirs('temp', exist_ok=True)
    os.makedirs('historical', exist_ok=True)

    # Current results (for dashboard generator)
    with open('temp/current_reports.json', 'w') as f:
        json.dump(reports, f, indent=2, default=str)

    # Historical snapshot
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    source_name = Path(filepath).stem
    hist_path = f'historical/{source_name}_{timestamp}.json'
    with open(hist_path, 'w') as f:
        json.dump(reports, f, indent=2, default=str)

    print()
    print(f"  {len(reports['available_reports'])} reports generated: {', '.join(reports['available_reports'])}")


if __name__ == "__main__":
    main()
