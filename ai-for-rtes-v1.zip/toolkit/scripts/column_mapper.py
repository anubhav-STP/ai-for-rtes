#!/usr/bin/env python3
"""
Column Auto-Mapper for AI for RTEs
Reads CSV/Excel column headers, auto-maps them to known metric fields,
and asks the user to confirm (or correct) the mapping.

Mapping is saved to config/column_mapping.json for reuse.
"""

import json
import os
import re
import sys

# Where we save the confirmed mapping
CONFIG_DIR = "config"
MAPPING_FILE = os.path.join(CONFIG_DIR, "column_mapping.json")

# Fields we need, with keyword lists for auto-detection
# Each field has: description (shown to user), keywords (for matching), required (bool)
FIELD_DEFINITIONS = {
    "team": {
        "description": "Team or squad name",
        "keywords": ["team", "squad", "group", "team_name", "team name", "agile team", "scrum team"],
        "required": True
    },
    "sprint": {
        "description": "Sprint or iteration name",
        "keywords": ["sprint", "iteration", "timebox", "iteration_name", "sprint_name", "iteration name", "sprint name"],
        "required": True
    },
    "story_points": {
        "description": "Story points or estimate",
        "keywords": ["story points", "story_points", "points", "sp", "estimate", "size", "effort", "story pts"],
        "required": True
    },
    "status": {
        "description": "Status of the work item",
        "keywords": ["status", "state", "workflow", "stage", "workflow status", "issue status"],
        "required": True
    },
    "issue_type": {
        "description": "Type of work item (story, bug, task, feature, epic)",
        "keywords": ["issue type", "issue_type", "type", "work item type", "issuetype", "work_item_type", "item type", "category", "sticky_type_name"],
        "required": False
    },
    "created_date": {
        "description": "Date the item was created",
        "keywords": ["created", "creation", "created date", "created_date", "date created", "creation date", "opened", "open date"],
        "required": False
    },
    "resolved_date": {
        "description": "Date the item was completed or resolved",
        "keywords": ["resolved", "resolved date", "resolved_date", "closed", "completed", "done date", "completion date", "end date", "close date"],
        "required": False
    },
    "priority": {
        "description": "Priority level",
        "keywords": ["priority", "severity", "urgency", "priority_name"],
        "required": False
    },
    "assignee": {
        "description": "Person assigned to the item",
        "keywords": ["assignee", "assigned to", "owner", "assigned", "developer", "responsible"],
        "required": False
    },
    "epic": {
        "description": "Epic or feature name",
        "keywords": ["epic", "epic name", "epic_name", "epic link", "epic_link", "feature", "parent", "parent_name"],
        "required": False
    },
    "label": {
        "description": "Labels or tags",
        "keywords": ["label", "labels", "tag", "tags"],
        "required": False
    },
    "component": {
        "description": "Component or area",
        "keywords": ["component", "components", "area", "module", "area path"],
        "required": False
    }
}

# Status values that mean "done" — used for velocity and flow calculations
DONE_STATUS_KEYWORDS = [
    "done", "closed", "resolved", "completed", "accepted", "finished",
    "delivered", "released", "verified", "complete"
]


def score_match(column_name, keywords):
    """Score how well a column name matches a set of keywords. Higher = better match."""
    col_lower = column_name.lower().strip()

    # Exact match
    for kw in keywords:
        if col_lower == kw.lower():
            return 100

    # Column contains keyword exactly
    for kw in keywords:
        if kw.lower() in col_lower:
            return 80

    # Keyword words appear in column
    for kw in keywords:
        kw_words = set(kw.lower().split())
        col_words = set(re.split(r'[\s_\-\.]+', col_lower))
        if kw_words and kw_words.issubset(col_words):
            return 70

    # Partial word match
    for kw in keywords:
        kw_words = kw.lower().split()
        for word in kw_words:
            if word in col_lower and len(word) > 2:
                return 40

    return 0


def auto_map_columns(column_headers):
    """
    Given a list of column headers from the user's file,
    return a dict of {field_name: best_matching_column} with confidence scores.
    """
    mapping = {}
    used_columns = set()

    for field_name, field_def in FIELD_DEFINITIONS.items():
        best_score = 0
        best_column = None

        for col in column_headers:
            if col in used_columns:
                continue
            s = score_match(col, field_def["keywords"])
            if s > best_score:
                best_score = s
                best_column = col

        if best_column and best_score >= 40:
            mapping[field_name] = {
                "column": best_column,
                "score": best_score
            }
            used_columns.add(best_column)
        else:
            mapping[field_name] = {
                "column": None,
                "score": 0
            }

    return mapping


def display_mapping_for_confirmation(mapping, column_headers):
    """Show the auto-mapped columns and ask user to confirm."""
    print()
    print("=" * 60)
    print("  COLUMN MAPPING")
    print("  I matched your columns to the fields I need.")
    print("=" * 60)
    print()

    # Determine which reports are possible
    mapped_fields = [f for f, m in mapping.items() if m["column"] is not None]

    for field_name, field_def in FIELD_DEFINITIONS.items():
        match = mapping[field_name]
        required_tag = " (required)" if field_def["required"] else ""

        if match["column"]:
            confidence = "OK" if match["score"] >= 70 else "?"
            print(f"  {field_def['description']:<40} -> \"{match['column']}\"  [{confidence}]")
        else:
            if field_def["required"]:
                print(f"  {field_def['description']:<40} -> (not found)  [NEEDED]")
            else:
                print(f"  {field_def['description']:<40} -> (not found)")

    print()
    print("-" * 60)

    # Show what reports are possible
    print()
    print("  REPORTS I CAN GENERATE:")
    print()

    has_team = mapping["team"]["column"] is not None
    has_sprint = mapping["sprint"]["column"] is not None
    has_points = mapping["story_points"]["column"] is not None
    has_status = mapping["status"]["column"] is not None
    has_created = mapping["created_date"]["column"] is not None
    has_resolved = mapping["resolved_date"]["column"] is not None
    has_type = mapping["issue_type"]["column"] is not None
    has_epic = mapping["epic"]["column"] is not None
    has_priority = mapping["priority"]["column"] is not None

    if has_team and has_sprint and has_points and has_status:
        print("  [YES]  Velocity per team per sprint")
        print("  [YES]  Scope change tracking")
    else:
        missing = []
        if not has_team: missing.append("team")
        if not has_sprint: missing.append("sprint")
        if not has_points: missing.append("story points")
        if not has_status: missing.append("status")
        print(f"  [NO]   Velocity & Scope Change (missing: {', '.join(missing)})")

    if has_status and has_type:
        print("  [YES]  Work item distribution (by type and status)")
    elif has_status:
        print("  [YES]  Work item distribution (by status only)")

    if has_created and has_resolved:
        print("  [YES]  Cycle time analysis")
    else:
        print("  [NO]   Cycle time analysis (need created + resolved dates)")

    if has_epic and has_points and has_status:
        print("  [YES]  Epic/Feature progress tracking")
    elif has_epic:
        print("  [YES]  Epic/Feature progress tracking (count-based, no points)")

    if has_priority and has_status:
        print("  [YES]  Priority breakdown")

    if has_team and has_points and has_status:
        print("  [YES]  Team comparison")

    print()
    return mapping


def interactive_confirm(mapping, column_headers):
    """Let the user confirm or change the mapping."""
    while True:
        print("  Options:")
        print("    Press Enter to confirm this mapping")
        print("    Type 'change' to fix a mapping")
        print("    Type 'list' to see all your columns")
        print()

        choice = input("  Your choice: ").strip().lower()

        if choice == "":
            # Confirmed
            return mapping

        elif choice == "list":
            print()
            print("  Your columns:")
            for i, col in enumerate(column_headers, 1):
                print(f"    {i}. {col}")
            print()

        elif choice == "change":
            print()
            print("  Which field do you want to change?")
            field_names = list(FIELD_DEFINITIONS.keys())
            for i, fname in enumerate(field_names, 1):
                current = mapping[fname]["column"] or "(not set)"
                print(f"    {i}. {FIELD_DEFINITIONS[fname]['description']} -> {current}")
            print()

            try:
                field_idx = int(input("  Enter number: ").strip()) - 1
                if 0 <= field_idx < len(field_names):
                    selected_field = field_names[field_idx]
                    print()
                    print(f"  Select column for '{FIELD_DEFINITIONS[selected_field]['description']}':")
                    print(f"    0. (none / skip)")
                    for i, col in enumerate(column_headers, 1):
                        print(f"    {i}. {col}")
                    print()

                    col_idx = int(input("  Enter number: ").strip())
                    if col_idx == 0:
                        mapping[selected_field] = {"column": None, "score": 0}
                        print(f"  -> Cleared '{FIELD_DEFINITIONS[selected_field]['description']}'")
                    elif 1 <= col_idx <= len(column_headers):
                        mapping[selected_field] = {"column": column_headers[col_idx - 1], "score": 100}
                        print(f"  -> Set to '{column_headers[col_idx - 1]}'")
                    else:
                        print("  Invalid number.")
                else:
                    print("  Invalid number.")
            except ValueError:
                print("  Please enter a number.")

            print()
            # Re-display
            display_mapping_for_confirmation(mapping, column_headers)

        else:
            print("  Please press Enter, or type 'change' or 'list'.")


def save_mapping(mapping):
    """Save the confirmed mapping to config file."""
    os.makedirs(CONFIG_DIR, exist_ok=True)

    # Simplify for storage: just field -> column name
    simple_mapping = {}
    for field_name, match in mapping.items():
        if match["column"]:
            simple_mapping[field_name] = match["column"]

    with open(MAPPING_FILE, 'w') as f:
        json.dump(simple_mapping, f, indent=2)

    print(f"  Mapping saved to {MAPPING_FILE}")
    print(f"  You will not be asked again unless you delete this file.")
    print()


def load_saved_mapping():
    """Load a previously saved mapping, if it exists."""
    if os.path.exists(MAPPING_FILE):
        try:
            with open(MAPPING_FILE, 'r') as f:
                return json.load(f)
        except Exception:
            return None
    return None


def get_column_mapping(column_headers):
    """
    Main entry point. Returns a simple dict of {field: column_name}.
    If a saved mapping exists and matches the columns, uses it.
    Otherwise, auto-maps and asks the user to confirm.
    """
    saved = load_saved_mapping()

    if saved:
        # Check if saved mapping columns still exist in the file
        all_valid = all(col in column_headers for col in saved.values())
        if all_valid:
            print()
            print("  Using saved column mapping from last time.")
            print(f"  (To change, delete {MAPPING_FILE})")
            print()
            return saved
        else:
            print()
            print("  Your file columns have changed since last time.")
            print("  Let me re-map them.")
            print()

    # Auto-map
    mapping = auto_map_columns(column_headers)

    # Display and confirm
    display_mapping_for_confirmation(mapping, column_headers)
    mapping = interactive_confirm(mapping, column_headers)

    # Save
    save_mapping(mapping)

    # Return simple dict
    result = {}
    for field_name, match in mapping.items():
        if match["column"]:
            result[field_name] = match["column"]
    return result


if __name__ == "__main__":
    # Test mode: pass column names as arguments
    if len(sys.argv) > 1:
        test_columns = sys.argv[1:]
    else:
        test_columns = [
            "Summary", "Issue key", "Issue Type", "Status", "Priority",
            "Assignee", "Created", "Resolved", "Story Points",
            "Sprint", "Epic Link", "Labels", "Component/s", "Team"
        ]
        print("  (Using sample Jira columns for testing)")

    result = get_column_mapping(test_columns)
    print("\n  Final mapping:")
    for field, col in result.items():
        print(f"    {field} -> {col}")
