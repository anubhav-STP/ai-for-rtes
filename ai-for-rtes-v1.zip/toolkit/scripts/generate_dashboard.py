#!/usr/bin/env python3
"""
AI for RTEs - Dashboard Generator
Reads calculated reports from temp/current_reports.json
and generates a self-contained HTML dashboard.
"""

import json
import os
from pathlib import Path


def load_reports():
    """Load the calculated reports."""
    report_path = 'temp/current_reports.json'
    if not os.path.exists(report_path):
        print("  No report data found. Run parse_and_calculate.py first.")
        return None

    with open(report_path, 'r') as f:
        return json.load(f)


def generate_html(reports):
    """Generate the full HTML dashboard."""

    available = reports.get('available_reports', [])
    metadata = reports.get('metadata', {})

    # Prepare data for JS
    reports_json = json.dumps(reports, default=str)

    html = f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI for RTEs - Dashboard</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.js"></script>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f0f2f5; color: #1a1a2e; line-height: 1.6; }}

        .header {{
            background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
            color: white; padding: 30px 40px; margin-bottom: 30px;
        }}
        .header h1 {{ font-size: 24px; font-weight: 600; }}
        .header .subtitle {{ color: #94a3b8; font-size: 14px; margin-top: 5px; }}

        .container {{ max-width: 1400px; margin: 0 auto; padding: 0 30px 40px; }}

        .metrics-row {{
            display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px; margin-bottom: 30px;
        }}

        .metric-card {{
            background: white; padding: 22px; border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
        }}
        .metric-label {{ font-size: 13px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; }}
        .metric-value {{ font-size: 32px; font-weight: 700; margin: 8px 0; color: #1a1a2e; }}
        .metric-detail {{ font-size: 13px; color: #9ca3af; }}

        .chart-section {{
            background: white; padding: 28px; border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08); margin-bottom: 25px;
        }}
        .chart-title {{ font-size: 18px; font-weight: 600; margin-bottom: 20px; color: #1a1a2e; }}
        .chart-subtitle {{ font-size: 13px; color: #6b7280; margin-top: -12px; margin-bottom: 20px; }}

        table {{ width: 100%; border-collapse: collapse; }}
        th {{ text-align: left; padding: 12px 16px; background: #f8fafc; font-weight: 600; font-size: 13px; color: #4b5563; border-bottom: 2px solid #e5e7eb; }}
        td {{ padding: 12px 16px; border-bottom: 1px solid #f3f4f6; font-size: 14px; }}
        tr:hover td {{ background: #f8fafc; }}

        .badge {{
            display: inline-block; padding: 3px 10px; border-radius: 12px;
            font-size: 12px; font-weight: 600;
        }}
        .badge-green {{ background: #d1fae5; color: #065f46; }}
        .badge-yellow {{ background: #fef3c7; color: #92400e; }}
        .badge-red {{ background: #fee2e2; color: #991b1b; }}
        .badge-blue {{ background: #dbeafe; color: #1e40af; }}

        .tab-bar {{
            display: flex; gap: 0; margin-bottom: 25px; border-bottom: 2px solid #e5e7eb;
        }}
        .tab {{
            padding: 12px 24px; cursor: pointer; font-size: 14px; font-weight: 500;
            color: #6b7280; border-bottom: 2px solid transparent; margin-bottom: -2px;
            transition: all 0.2s;
        }}
        .tab:hover {{ color: #1a1a2e; }}
        .tab.active {{ color: #0f3460; border-bottom-color: #0f3460; font-weight: 600; }}

        .tab-content {{ display: none; }}
        .tab-content.active {{ display: block; }}

        .progress-bar {{
            background: #e5e7eb; border-radius: 8px; height: 10px; overflow: hidden;
        }}
        .progress-fill {{
            height: 100%; border-radius: 8px; transition: width 0.3s;
        }}
        .progress-green {{ background: #10b981; }}
        .progress-yellow {{ background: #f59e0b; }}
        .progress-red {{ background: #ef4444; }}

        .no-data {{
            text-align: center; padding: 60px 20px; color: #9ca3af;
        }}
        .no-data h3 {{ color: #6b7280; margin-bottom: 10px; }}

        .footer {{
            text-align: center; padding: 30px; color: #9ca3af; font-size: 13px;
        }}

        @media (max-width: 768px) {{
            .container {{ padding: 0 15px 30px; }}
            .metrics-row {{ grid-template-columns: repeat(2, 1fr); }}
            .header {{ padding: 20px; }}
        }}
    </style>
</head>
<body>

<div class="header">
    <h1>AI for Release Train Engineers</h1>
    <div class="subtitle">
        Source: {metadata.get('source_file', 'Unknown')} |
        {metadata.get('total_rows', 0)} items |
        Generated: {metadata.get('generated_at', '')[:19].replace('T', ' ')}
    </div>
</div>

<div class="container">
    <div id="summary-cards" class="metrics-row"></div>

    <div class="tab-bar" id="tabBar"></div>
    <div id="tabContent"></div>
</div>

<div class="footer">
    AI for RTEs — Your data stays on your machine. Always.
</div>

<script>
const DATA = {reports_json};

// ─── Tab System ───
let tabs = [];
let activeTab = null;

function registerTab(id, label, renderFn) {{
    tabs.push({{ id, label, renderFn }});
}}

function renderTabs() {{
    const bar = document.getElementById('tabBar');
    bar.innerHTML = tabs.map(t =>
        `<div class="tab ${{t.id === activeTab ? 'active' : ''}}" onclick="switchTab('${{t.id}}')">${{t.label}}</div>`
    ).join('');

    const content = document.getElementById('tabContent');
    content.innerHTML = tabs.map(t =>
        `<div class="tab-content ${{t.id === activeTab ? 'active' : ''}}" id="tab-${{t.id}}"></div>`
    ).join('');

    // Render active tab
    const active = tabs.find(t => t.id === activeTab);
    if (active) active.renderFn(document.getElementById(`tab-${{activeTab}}`));
}}

function switchTab(id) {{
    activeTab = id;
    renderTabs();
}}

// ─── Helper Functions ───
function getProgressColor(pct) {{
    if (pct >= 80) return 'progress-green';
    if (pct >= 50) return 'progress-yellow';
    return 'progress-red';
}}

function getBadgeColor(pct) {{
    if (pct >= 80) return 'badge-green';
    if (pct >= 50) return 'badge-yellow';
    return 'badge-red';
}}

const COLORS = [
    '#0f3460', '#e94560', '#16213e', '#0ea5e9', '#8b5cf6',
    '#10b981', '#f59e0b', '#ec4899', '#6366f1', '#14b8a6',
    '#f97316', '#84cc16', '#a855f7', '#06b6d4', '#ef4444'
];

// ─── Summary Cards ───
function renderSummaryCards() {{
    const el = document.getElementById('summary-cards');
    let html = '';

    const meta = DATA.metadata || {{}};
    html += `<div class="metric-card">
        <div class="metric-label">Total Items</div>
        <div class="metric-value">${{meta.total_rows || 0}}</div>
        <div class="metric-detail">${{(DATA.available_reports || []).length}} reports available</div>
    </div>`;

    if (DATA.velocity) {{
        const v = DATA.velocity;
        html += `<div class="metric-card">
            <div class="metric-label">Total Velocity</div>
            <div class="metric-value">${{v.total_velocity || 0}}</div>
            <div class="metric-detail">${{v.team_count || 0}} teams, ${{(v.sprints || []).length}} sprints</div>
        </div>`;
    }}

    if (DATA.cycle_time) {{
        const ct = DATA.cycle_time.overall;
        html += `<div class="metric-card">
            <div class="metric-label">Avg Cycle Time</div>
            <div class="metric-value">${{ct.average_days}} days</div>
            <div class="metric-detail">Median: ${{ct.median_days}} days (${{ct.items_measured}} items)</div>
        </div>`;
    }}

    if (DATA.team_comparison) {{
        const teams = Object.values(DATA.team_comparison);
        const totalDone = teams.reduce((s, t) => s + t.done_points, 0);
        const totalAll = teams.reduce((s, t) => s + t.total_points, 0);
        const overallPct = totalAll > 0 ? Math.round(totalDone / totalAll * 100) : 0;
        html += `<div class="metric-card">
            <div class="metric-label">Overall Completion</div>
            <div class="metric-value">${{overallPct}}%</div>
            <div class="metric-detail">${{Math.round(totalDone)}} / ${{Math.round(totalAll)}} points</div>
        </div>`;
    }}

    if (DATA.epic_progress) {{
        const epics = Object.keys(DATA.epic_progress);
        html += `<div class="metric-card">
            <div class="metric-label">Epics / Features</div>
            <div class="metric-value">${{epics.length}}</div>
            <div class="metric-detail">Tracked in your data</div>
        </div>`;
    }}

    el.innerHTML = html;
}}

// ─── Velocity Tab ───
function renderVelocity(container) {{
    const v = DATA.velocity;
    if (!v) {{ container.innerHTML = '<div class="no-data"><h3>Velocity data not available</h3></div>'; return; }}

    const sprints = v.sprints || [];
    const teams = v.teams || {{}};
    const teamNames = Object.keys(teams);

    // Chart
    let html = '<div class="chart-section"><h3 class="chart-title">Velocity per Team per Sprint</h3>';
    html += '<p class="chart-subtitle">Story points completed by each team in each sprint</p>';
    html += '<canvas id="velocityChart"></canvas></div>';

    // Table
    html += '<div class="chart-section"><h3 class="chart-title">Velocity Details</h3>';
    html += '<table><thead><tr><th>Team</th>';
    sprints.forEach(s => html += `<th>${{s}}</th>`);
    html += '<th>Total</th><th>Average</th></tr></thead><tbody>';

    teamNames.forEach(team => {{
        const t = teams[team];
        html += `<tr><td><strong>${{team}}</strong></td>`;
        sprints.forEach(s => {{
            const pts = t.sprints[s] || 0;
            html += `<td>${{pts}}</td>`;
        }});
        html += `<td><strong>${{t.total}}</strong></td>`;
        html += `<td>${{t.average}}</td></tr>`;
    }});

    html += '</tbody></table></div>';
    container.innerHTML = html;

    // Draw chart
    const ctx = document.getElementById('velocityChart');
    new Chart(ctx, {{
        type: 'bar',
        data: {{
            labels: sprints,
            datasets: teamNames.map((team, i) => ({{
                label: team,
                data: sprints.map(s => teams[team].sprints[s] || 0),
                backgroundColor: COLORS[i % COLORS.length] + 'cc',
                borderColor: COLORS[i % COLORS.length],
                borderWidth: 1
            }}))
        }},
        options: {{
            responsive: true,
            maintainAspectRatio: true,
            aspectRatio: 3,
            plugins: {{ legend: {{ position: 'bottom' }} }},
            scales: {{
                y: {{ beginAtZero: true, title: {{ display: true, text: 'Story Points' }} }},
                x: {{ title: {{ display: true, text: 'Sprint' }} }}
            }}
        }}
    }});
}}

// ─── Scope Change Tab ───
function renderScopeChange(container) {{
    const sc = DATA.scope_change;
    if (!sc) {{ container.innerHTML = '<div class="no-data"><h3>Scope change data not available</h3></div>'; return; }}

    const teams = Object.keys(sc);

    // Gather all sprints
    const allSprints = new Set();
    teams.forEach(t => Object.keys(sc[t]).forEach(s => allSprints.add(s)));
    const sprints = Array.from(allSprints).sort();

    let html = '<div class="chart-section"><h3 class="chart-title">Scope & Completion per Sprint</h3>';
    html += '<p class="chart-subtitle">Total items vs completed items per team per sprint</p>';
    html += '<canvas id="scopeChart" height="300"></canvas></div>';

    // Table
    html += '<div class="chart-section"><h3 class="chart-title">Scope Change Details</h3>';
    html += '<table><thead><tr><th>Team</th><th>Sprint</th><th>Total Items</th><th>Done Items</th><th>Total Points</th><th>Done Points</th><th>Completion</th></tr></thead><tbody>';

    teams.forEach(team => {{
        sprints.forEach(sprint => {{
            const d = sc[team][sprint];
            if (!d) return;
            const pctClass = getBadgeColor(d.completion_rate);
            html += `<tr><td>${{team}}</td><td>${{sprint}}</td><td>${{d.total_items}}</td><td>${{d.done_items}}</td><td>${{d.total_points}}</td><td>${{d.done_points}}</td><td><span class="badge ${{pctClass}}">${{d.completion_rate}}%</span></td></tr>`;
        }});
    }});

    html += '</tbody></table></div>';
    container.innerHTML = html;

    // Chart: stacked bar of total vs done per sprint (all teams)
    const totalBySprint = sprints.map(s => {{
        let total = 0;
        teams.forEach(t => {{ if (sc[t][s]) total += sc[t][s].total_points; }});
        return total;
    }});
    const doneBySprint = sprints.map(s => {{
        let total = 0;
        teams.forEach(t => {{ if (sc[t][s]) total += sc[t][s].done_points; }});
        return total;
    }});

    new Chart(document.getElementById('scopeChart'), {{
        type: 'bar',
        data: {{
            labels: sprints,
            datasets: [
                {{ label: 'Total Points (Scope)', data: totalBySprint, backgroundColor: '#0f3460cc' }},
                {{ label: 'Done Points', data: doneBySprint, backgroundColor: '#10b981cc' }}
            ]
        }},
        options: {{
            responsive: true,
            plugins: {{ legend: {{ position: 'bottom' }} }},
            scales: {{ y: {{ beginAtZero: true }} }}
        }}
    }});
}}

// ─── Work Distribution Tab ───
function renderDistribution(container) {{
    const wd = DATA.work_distribution;
    if (!wd) {{ container.innerHTML = '<div class="no-data"><h3>Distribution data not available</h3></div>'; return; }}

    let html = '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px;">';

    // Status chart
    html += '<div class="chart-section"><h3 class="chart-title">By Status</h3><canvas id="statusChart"></canvas></div>';

    // Type chart
    if (wd.by_type) {{
        html += '<div class="chart-section"><h3 class="chart-title">By Type</h3><canvas id="typeChart"></canvas></div>';
    }}

    html += '</div>';

    // Points by status table
    if (wd.points_by_status) {{
        html += '<div class="chart-section"><h3 class="chart-title">Points by Status</h3>';
        html += '<table><thead><tr><th>Status</th><th>Points</th><th>Share</th></tr></thead><tbody>';
        const totalPts = Object.values(wd.points_by_status).reduce((s, v) => s + v, 0);
        Object.entries(wd.points_by_status).sort((a, b) => b[1] - a[1]).forEach(([status, pts]) => {{
            const pct = totalPts > 0 ? Math.round(pts / totalPts * 100) : 0;
            html += `<tr><td>${{status}}</td><td>${{Math.round(pts)}}</td><td>
                <div class="progress-bar" style="width:200px;display:inline-block;vertical-align:middle;">
                    <div class="progress-fill progress-green" style="width:${{pct}}%"></div>
                </div> ${{pct}}%
            </td></tr>`;
        }});
        html += '</tbody></table></div>';
    }}

    container.innerHTML = html;

    // Draw charts
    if (wd.by_status) {{
        const labels = Object.keys(wd.by_status);
        new Chart(document.getElementById('statusChart'), {{
            type: 'doughnut',
            data: {{
                labels: labels,
                datasets: [{{ data: Object.values(wd.by_status), backgroundColor: COLORS.slice(0, labels.length) }}]
            }},
            options: {{ responsive: true, plugins: {{ legend: {{ position: 'bottom' }} }} }}
        }});
    }}

    if (wd.by_type) {{
        const labels = Object.keys(wd.by_type);
        new Chart(document.getElementById('typeChart'), {{
            type: 'doughnut',
            data: {{
                labels: labels,
                datasets: [{{ data: Object.values(wd.by_type), backgroundColor: COLORS.slice(0, labels.length) }}]
            }},
            options: {{ responsive: true, plugins: {{ legend: {{ position: 'bottom' }} }} }}
        }});
    }}
}}

// ─── Cycle Time Tab ───
function renderCycleTime(container) {{
    const ct = DATA.cycle_time;
    if (!ct) {{ container.innerHTML = '<div class="no-data"><h3>Cycle time data not available</h3><p>Need both created and resolved dates in your data.</p></div>'; return; }}

    let html = '';

    // Summary cards
    html += '<div class="metrics-row" style="margin-bottom:25px;">';
    html += `<div class="metric-card"><div class="metric-label">Average</div><div class="metric-value">${{ct.overall.average_days}} days</div></div>`;
    html += `<div class="metric-card"><div class="metric-label">Median</div><div class="metric-value">${{ct.overall.median_days}} days</div></div>`;
    html += `<div class="metric-card"><div class="metric-label">Fastest</div><div class="metric-value">${{ct.overall.min_days}} days</div></div>`;
    html += `<div class="metric-card"><div class="metric-label">Slowest</div><div class="metric-value">${{ct.overall.max_days}} days</div></div>`;
    html += '</div>';

    // Distribution chart
    if (ct.distribution) {{
        html += '<div class="chart-section"><h3 class="chart-title">Cycle Time Distribution</h3>';
        html += '<p class="chart-subtitle">How long items take from creation to completion</p>';
        html += '<canvas id="cycleDistChart" height="250"></canvas></div>';
    }}

    // By team table
    if (ct.by_team) {{
        html += '<div class="chart-section"><h3 class="chart-title">Cycle Time by Team</h3>';
        html += '<table><thead><tr><th>Team</th><th>Average (days)</th><th>Median (days)</th><th>Items</th></tr></thead><tbody>';
        Object.entries(ct.by_team).sort((a, b) => a[1].average_days - b[1].average_days).forEach(([team, data]) => {{
            html += `<tr><td>${{team}}</td><td>${{data.average_days}}</td><td>${{data.median_days}}</td><td>${{data.items_measured}}</td></tr>`;
        }});
        html += '</tbody></table></div>';
    }}

    // By type table
    if (ct.by_type) {{
        html += '<div class="chart-section"><h3 class="chart-title">Cycle Time by Item Type</h3>';
        html += '<table><thead><tr><th>Type</th><th>Average (days)</th><th>Median (days)</th><th>Items</th></tr></thead><tbody>';
        Object.entries(ct.by_type).sort((a, b) => a[1].average_days - b[1].average_days).forEach(([type, data]) => {{
            html += `<tr><td>${{type}}</td><td>${{data.average_days}}</td><td>${{data.median_days}}</td><td>${{data.items_measured}}</td></tr>`;
        }});
        html += '</tbody></table></div>';
    }}

    container.innerHTML = html;

    // Draw distribution chart
    if (ct.distribution) {{
        const labels = Object.keys(ct.distribution);
        const values = Object.values(ct.distribution);
        new Chart(document.getElementById('cycleDistChart'), {{
            type: 'bar',
            data: {{
                labels: labels,
                datasets: [{{ label: 'Number of Items', data: values, backgroundColor: '#0f3460cc', borderColor: '#0f3460', borderWidth: 1 }}]
            }},
            options: {{
                responsive: true,
                plugins: {{ legend: {{ display: false }} }},
                scales: {{ y: {{ beginAtZero: true, title: {{ display: true, text: 'Items' }} }} }}
            }}
        }});
    }}
}}

// ─── Epic Progress Tab ───
function renderEpicProgress(container) {{
    const ep = DATA.epic_progress;
    if (!ep) {{ container.innerHTML = '<div class="no-data"><h3>Epic/Feature data not available</h3><p>Need an epic or feature column in your data.</p></div>'; return; }}

    const epics = Object.entries(ep).sort((a, b) => {{
        const pctA = a[1].points_completion_pct || a[1].completion_pct || 0;
        const pctB = b[1].points_completion_pct || b[1].completion_pct || 0;
        return pctB - pctA;
    }});

    let html = '<div class="chart-section"><h3 class="chart-title">Epic / Feature Progress</h3>';
    html += '<p class="chart-subtitle">Completion status of each epic or feature</p>';
    html += '<table><thead><tr><th>Epic / Feature</th><th>Progress</th><th>Items</th>';

    const hasPoints = epics.some(([_, d]) => d.total_points !== undefined);
    if (hasPoints) html += '<th>Points</th>';
    html += '<th>Status Breakdown</th></tr></thead><tbody>';

    epics.forEach(([name, data]) => {{
        const pct = hasPoints ? (data.points_completion_pct || 0) : data.completion_pct;
        const colorClass = getProgressColor(pct);
        const badgeClass = getBadgeColor(pct);

        html += `<tr><td><strong>${{name}}</strong></td>`;
        html += `<td style="min-width:200px"><div class="progress-bar"><div class="progress-fill ${{colorClass}}" style="width:${{pct}}%"></div></div>
            <span class="badge ${{badgeClass}}" style="margin-top:4px">${{pct}}%</span></td>`;
        html += `<td>${{data.done_items}} / ${{data.total_items}}</td>`;

        if (hasPoints) {{
            html += `<td>${{Math.round(data.done_points || 0)}} / ${{Math.round(data.total_points || 0)}}</td>`;
        }}

        // Status breakdown as small badges
        const statusHtml = Object.entries(data.status_breakdown || {{}}).map(([s, c]) =>
            `<span class="badge badge-blue" style="margin:2px">${{s}}: ${{c}}</span>`
        ).join(' ');
        html += `<td>${{statusHtml}}</td></tr>`;
    }});

    html += '</tbody></table></div>';
    container.innerHTML = html;
}}

// ─── Priority Tab ───
function renderPriority(container) {{
    const pb = DATA.priority_breakdown;
    if (!pb) {{ container.innerHTML = '<div class="no-data"><h3>Priority data not available</h3></div>'; return; }}

    let html = '<div style="display:grid;grid-template-columns:1fr 1fr;gap:25px;">';
    html += '<div class="chart-section"><h3 class="chart-title">Items by Priority</h3><canvas id="priorityChart"></canvas></div>';
    html += '<div class="chart-section"><h3 class="chart-title">Completion by Priority</h3><canvas id="priorityCompChart"></canvas></div>';
    html += '</div>';

    html += '<div class="chart-section"><h3 class="chart-title">Priority Details</h3>';
    html += '<table><thead><tr><th>Priority</th><th>Total</th><th>Done</th><th>Completion</th></tr></thead><tbody>';

    Object.entries(pb).forEach(([priority, data]) => {{
        const badgeClass = getBadgeColor(data.completion_pct);
        html += `<tr><td><strong>${{priority}}</strong></td><td>${{data.total}}</td><td>${{data.done}}</td>
            <td><span class="badge ${{badgeClass}}">${{data.completion_pct}}%</span></td></tr>`;
    }});
    html += '</tbody></table></div>';

    container.innerHTML = html;

    // Charts
    const labels = Object.keys(pb);
    new Chart(document.getElementById('priorityChart'), {{
        type: 'doughnut',
        data: {{ labels, datasets: [{{ data: labels.map(l => pb[l].total), backgroundColor: COLORS.slice(0, labels.length) }}] }},
        options: {{ responsive: true, plugins: {{ legend: {{ position: 'bottom' }} }} }}
    }});

    new Chart(document.getElementById('priorityCompChart'), {{
        type: 'bar',
        data: {{
            labels,
            datasets: [
                {{ label: 'Done', data: labels.map(l => pb[l].done), backgroundColor: '#10b981cc' }},
                {{ label: 'Remaining', data: labels.map(l => pb[l].total - pb[l].done), backgroundColor: '#e5e7ebcc' }}
            ]
        }},
        options: {{ responsive: true, scales: {{ x: {{ stacked: true }}, y: {{ stacked: true, beginAtZero: true }} }}, plugins: {{ legend: {{ position: 'bottom' }} }} }}
    }});
}}

// ─── Team Comparison Tab ───
function renderTeamComparison(container) {{
    const tc = DATA.team_comparison;
    if (!tc) {{ container.innerHTML = '<div class="no-data"><h3>Team comparison data not available</h3></div>'; return; }}

    const teams = Object.entries(tc).sort((a, b) => b[1].done_points - a[1].done_points);
    const teamNames = teams.map(t => t[0]);

    let html = '<div class="chart-section"><h3 class="chart-title">Team Comparison</h3>';
    html += '<p class="chart-subtitle">Points delivered vs total scope per team</p>';
    html += '<canvas id="teamCompChart" height="300"></canvas></div>';

    html += '<div class="chart-section"><h3 class="chart-title">Team Details</h3>';
    html += '<table><thead><tr><th>Team</th><th>Items (Done/Total)</th><th>Points (Done/Total)</th><th>Completion</th><th>Avg Points/Item</th></tr></thead><tbody>';

    teams.forEach(([name, data]) => {{
        const badgeClass = getBadgeColor(data.points_completion_pct);
        html += `<tr><td><strong>${{name}}</strong></td>`;
        html += `<td>${{data.done_items}} / ${{data.total_items}}</td>`;
        html += `<td>${{Math.round(data.done_points)}} / ${{Math.round(data.total_points)}}</td>`;
        html += `<td><div class="progress-bar" style="width:120px;display:inline-block;vertical-align:middle;">
            <div class="progress-fill ${{getProgressColor(data.points_completion_pct)}}" style="width:${{data.points_completion_pct}}%"></div>
        </div> <span class="badge ${{badgeClass}}">${{data.points_completion_pct}}%</span></td>`;
        html += `<td>${{data.avg_points_per_item || '-'}}</td></tr>`;
    }});

    html += '</tbody></table></div>';
    container.innerHTML = html;

    // Chart
    new Chart(document.getElementById('teamCompChart'), {{
        type: 'bar',
        data: {{
            labels: teamNames,
            datasets: [
                {{ label: 'Done Points', data: teams.map(t => t[1].done_points), backgroundColor: '#10b981cc' }},
                {{ label: 'Remaining Points', data: teams.map(t => t[1].total_points - t[1].done_points), backgroundColor: '#e5e7ebcc' }}
            ]
        }},
        options: {{
            responsive: true,
            scales: {{ x: {{ stacked: true }}, y: {{ stacked: true, beginAtZero: true, title: {{ display: true, text: 'Story Points' }} }} }},
            plugins: {{ legend: {{ position: 'bottom' }} }}
        }}
    }});
}}


// ─── Initialize ───
function init() {{
    renderSummaryCards();

    const available = DATA.available_reports || [];

    if (available.includes('velocity')) registerTab('velocity', 'Velocity', renderVelocity);
    if (available.includes('scope_change')) registerTab('scope', 'Scope Change', renderScopeChange);
    if (available.includes('work_distribution')) registerTab('distribution', 'Distribution', renderDistribution);
    if (available.includes('cycle_time')) registerTab('cycle', 'Cycle Time', renderCycleTime);
    if (available.includes('epic_progress')) registerTab('epics', 'Epics / Features', renderEpicProgress);
    if (available.includes('priority_breakdown')) registerTab('priority', 'Priority', renderPriority);
    if (available.includes('team_comparison')) registerTab('teams', 'Team Comparison', renderTeamComparison);

    if (tabs.length === 0) {{
        document.getElementById('tabContent').innerHTML = '<div class="no-data"><h3>No reports could be generated</h3><p>Please check your data and column mapping.</p></div>';
        return;
    }}

    activeTab = tabs[0].id;
    renderTabs();
}}

init();
</script>
</body>
</html>'''

    return html


def main():
    reports = load_reports()
    if not reports:
        return

    html = generate_html(reports)

    os.makedirs('output', exist_ok=True)
    output_path = 'output/rte_dashboard.html'

    with open(output_path, 'w') as f:
        f.write(html)

    print(f"  Dashboard saved to {output_path}")


if __name__ == "__main__":
    main()
